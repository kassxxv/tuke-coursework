from ortools.sat.python import cp_model
import json
import csv

class Task:
    def __init__(self, name, duration, devices, prerequisites, parallel):
        self.name = name
        self.duration = int(duration)
        self.devices = list(devices)
        self.prerequisites = list(prerequisites)
        self.parallel = bool(parallel)

class Scheduler:
    def __init__(self, tasks_dict, all_devices):
        self.tasks = tasks_dict
        self.devices = list(all_devices)
        self.model = cp_model.CpModel()
        self.start = {}
        self.end = {}
        self.device_choice = {}
        self.intervals = {}

    def build_model(self):
        horizon = sum(t.duration for t in self.tasks.values()) * 2

        for task in self.tasks.values():
            s = self.model.NewIntVar(0, horizon, f"start_{task.name}")
            e = self.model.NewIntVar(0, horizon, f"end_{task.name}")
            self.start[task.name] = s
            self.end[task.name] = e

            dev_choice = self.model.NewIntVar(0, max(0, len(task.devices) - 1), f"dev_{task.name}")
            self.device_choice[task.name] = dev_choice

            ints = []
            for i, dev in enumerate(task.devices):
                present = self.model.NewBoolVar(f"on_{task.name}_{dev}")
                interval = self.model.NewOptionalIntervalVar(s, task.duration, e, present, f"int_{task.name}_{dev}")
                ints.append((i, dev, present, interval))

                self.model.Add(dev_choice == i).OnlyEnforceIf(present)
                self.model.Add(dev_choice != i).OnlyEnforceIf(present.Not())

            self.model.AddExactlyOne(p for _, _, p, _ in ints)
            self.intervals[task.name] = ints

        for task in self.tasks.values():
            for pre in task.prerequisites:
                if pre not in self.start:
                    raise KeyError(f"Prerequisite task '{pre}' for '{task.name}' not found in tasks.")
                self.model.Add(self.start[task.name] >= self.end[pre])

        for dev in self.devices:
            non_parallel_intervals = []
            parallel_intervals = []
            for task in self.tasks.values():
                for _, dname, present, interval in self.intervals[task.name]:
                    if dname != dev:
                        continue
                    if task.parallel:
                        parallel_intervals.append((task.name, present, interval))
                    else:
                        non_parallel_intervals.append((task.name, present, interval))

            if non_parallel_intervals:
                self.model.AddNoOverlap([iv for _, _, iv in non_parallel_intervals])

            for _, p_present, p_iv in parallel_intervals:
                for _, np_present, np_iv in non_parallel_intervals:
                    self.model.AddNoOverlap([p_iv, np_iv])

        makespan = self.model.NewIntVar(0, horizon, "makespan")
        self.model.AddMaxEquality(makespan, list(self.end.values()))
        self.model.Minimize(makespan)

    def solve(self, time_limit=10):
        solver = cp_model.CpSolver()
        solver.parameters.max_time_in_seconds = time_limit
        solver.parameters.num_search_workers = 1
        status = solver.Solve(self.model)
        if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            print("No solution found.")
            return []
        
        result = []
        for name in self.tasks:
            dev_idx = solver.Value(self.device_choice[name])
            dev = self.tasks[name].devices[dev_idx]
            start = solver.Value(self.start[name])
            result.append((name, dev, start))
        result.sort(key=lambda x: x[2])
        return result

def main():
    with open("a2v6.json", encoding="utf-8") as f:
        data = json.load(f)

    tasks = {
        t["name"]: Task(
            t["name"],
            t["duration"],
            t["devices"],
            t.get("prerequisites", []),
            t.get("parallel", False)
        ) for t in data["tasks"]
    }

    sched = Scheduler(tasks, data["devices"])
    sched.build_model()
    solution = sched.solve(time_limit=10)

    with open("output.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        for row in solution:
            w.writerow(row)
        w.writerow([])    


if __name__ == "__main__":
    main()
